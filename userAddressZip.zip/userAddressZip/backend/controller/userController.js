const userTable = require("../model/user");
const addressTable = require("../model/address");

exports.userInsert = async (req, res) => {
  const { name, email } = req.body;
  try {
    if (!name || !email) {
      throw new Error("Please Insert All Fields");
    }
    const findUser = await userTable.findOne({ email: email });
    if (findUser !== null) {
      throw new Error("Email Already Exist");
    }
    const newUser = new userTable({ name: name, email: email });
    newUser.save();
    res.status(201).json({
      status: 201,
      message: "User Successfully Insert",
      newUser,
    });
  } catch (e) {
    res.status(400).json({
      status: 400,
      message: e.message,
    });
  }
};

exports.addressInsert = async (req, res) => {
  const userId = req.params.id;
  const { state, district, street, pincode } = req.body;
  try {
    if (!state || !district || !street || !pincode) {
      throw new Error("Please fill ALl the fields");
    }
    const newAddress = new addressTable({
      state: state,
      district: district,
      pinCode: pincode,
      street: street,
      userId: userId,
    });
    const savedAddress = await newAddress.save();
    const updateUser = await userTable.findByIdAndUpdate(userId, {
      $push: {
        addressId: savedAddress.id,
      },
    });

    res.status(201).json({
      status: 201,
      message: "Address Add Successfully",
      userId,
    });
  } catch (e) {
    res.status(400).json({
      status: 400,
      message: e.message,
    });
  }
};

exports.getAddress = async (req, res) => {
  const userId = req.params.id;
  try {
    const addressData = await userTable.findById(userId).populate("addressId");

    res.status(200).json({
      status: 200,
      data: addressData,
    });
  } catch (e) {
    console.log(e.message);
  }
};
