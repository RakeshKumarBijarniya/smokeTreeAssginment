const router = require("express").Router();
const userC = require("../controller/userController");

router.post("/userInsert", userC.userInsert);
router.post("/addressInsert/:id", userC.addressInsert);

router.get("/getAddress/:id", userC.getAddress);

module.exports = router;
