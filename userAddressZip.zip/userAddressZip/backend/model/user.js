const mongoose = require("mongoose");

const userSchema = mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  addressId: [{ type: mongoose.Schema.Types.ObjectId, ref: "address" }],
});

module.exports = mongoose.model("users", userSchema);
