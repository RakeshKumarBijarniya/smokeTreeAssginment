const mongoose = require("mongoose");

const addressSchema = mongoose.Schema({
  state: {
    type: String,
    reqired: true,
  },
  district: {
    type: String,
    reqired: true,
  },
  street: {
    type: String,
    reqired: true,
  },
  pinCode: {
    type: Number,
    required: true,
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "users",
    required: true,
  },
});

module.exports = mongoose.model("address", addressSchema);
