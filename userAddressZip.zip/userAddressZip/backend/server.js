const express = require("express");
const app = express();

require("./dbConfg/dbconfig");

app.use(express.json());

const apiRouter = require("./router/apiRouter");

app.use("/api", apiRouter);

app.listen(5000, console.log("Server Connected Succssfully"));
