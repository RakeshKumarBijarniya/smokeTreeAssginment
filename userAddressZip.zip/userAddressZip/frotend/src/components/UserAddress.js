import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";

const UserAddress = () => {
  const { id } = useParams();
  const [userAddressData, setUserAddressData] = useState([]);

  useEffect(() => {
    fetch(`/api/getAddress/${id}`)
      .then((response) => response.json())
      .then((data) => {
        if (data.status === 200) {
          console.log(data.data);
          setUserAddressData(data.data);
        }
      })
      .catch((e) => {
        console.log(e.message);
      });
  }, []);
  return (
    <section className="userSection">
      <div className="container">
        <div className="row">
          <div className="col-md-6 mt-5">
            <h1>Name: {userAddressData.name}</h1>
            <h3>Email: {userAddressData.email}</h3>
            <Link to={`/addressForm/${userAddressData._id}`}>
              <button className="btn btn-secondary form-control">
                Add New Address Here
              </button>
            </Link>
            <Link to="/">
              <button className="btn btn-warning mt-2 form-control">
                Add New User
              </button>
            </Link>
          </div>
          <div className="col-md-6 mt-3">
            <h2 className="text-center">User Address Here</h2>
            <table className="table table-hover">
              <thead>
                <tr>
                  <th>State</th>
                  <th>District</th>
                  <th>Street</th>
                  <th>Pin Code</th>
                </tr>
              </thead>
              <tbody>
                {userAddressData.addressId?.map((val, key) => (
                  <tr key={val._id}>
                    <td>{val.state}</td>
                    <td>{val.district}</td>
                    <td>{val.street}</td>
                    <td>{val.pinCode}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
};

export default UserAddress;
