import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

const Address = () => {
  const { id } = useParams();
  console.log(id);
  const [state, setState] = useState("");
  const [district, setDistrict] = useState("");
  const [street, setStreet] = useState("");
  const [pincode, setPinCode] = useState("");

  const navigate = useNavigate();
  const handleForm = (e) => {
    e.preventDefault();
    const addressData = { state, district, street, pincode };
    fetch(`/api/addressInsert/${id}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(addressData),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        if (data.status === 201) {
          navigate(`/userAddressDetails/${id}`);
        }
      })
      .catch((e) => {
        console.log(e.message);
      });
  };

  return (
    <section id="addressform">
      <div className="container">
        <div className="row">
          <div className="col-md-2"></div>
          <div className="col-md-8">
            <h2 className="text-center mt-2">Address Form</h2>
            <form
              onSubmit={(e) => {
                handleForm(e);
              }}
            >
              <label>State</label>
              <input
                type="text"
                placeholder="state"
                className="form-control"
                value={state}
                onChange={(e) => setState(e.target.value)}
              />
              <label>District</label>
              <input
                type="text"
                placeholder="District"
                className="form-control"
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
              />
              <label>Street</label>
              <input
                type="text"
                placeholder="Street"
                className="form-control"
                value={street}
                onChange={(e) => setStreet(e.target.value)}
              />
              <label>Pin Code</label>
              <input
                type="number"
                placeholder="Pin code"
                className="form-control"
                value={pincode}
                onChange={(e) => setPinCode(e.target.value)}
              />
              <button className="form-control btn btn-success mt-2">
                Add Address
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Address;
