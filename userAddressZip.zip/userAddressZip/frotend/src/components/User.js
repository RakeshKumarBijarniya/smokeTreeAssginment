import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const User = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  const navigate = useNavigate();
  const handleForm = (e) => {
    e.preventDefault();
    const userData = { name, email };
    fetch("/api/userInsert", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(userData),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.status === 201) {
          navigate(`/addressForm/${data.newUser._id}`);
        }
      })
      .catch((e) => {
        console.log(e.message);
      });
  };
  return (
    <section id="userSection">
      <div className="container">
        <div className="row">
          <div className="col-md-3"></div>
          <div className="col-md-6 mt-2 mid-container">
            <h2 className="text-center">User Form</h2>
            <form
              onSubmit={(e) => {
                handleForm(e);
              }}
            >
              <label>Name</label>
              <input
                placeholder="Enter Your Name"
                type="text"
                className="form-control"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
              <label>Email</label>
              <input
                placeholder="Enter Your Email"
                type="email"
                className="form-control"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <button className="btn btn-dark mt-2 form-control">
                Create User
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default User;
