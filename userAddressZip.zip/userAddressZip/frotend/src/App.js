import "./App.css";

import User from "./components/User";
import Address from "./components/Address";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import UserAddress from "./components/UserAddress";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<User />}></Route>
        <Route path="/addressForm/:id" element={<Address />}></Route>
        <Route path="/userAddressDetails/:id" element={<UserAddress />}></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
